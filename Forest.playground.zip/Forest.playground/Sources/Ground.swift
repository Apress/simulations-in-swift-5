import Foundation

public struct Ground: Plottable { }
