import Foundation
import UIKit
import CoreGraphics

// MARK: - ForestView
public class ForestView: UIView {
    
    var cellSize: Int = 10
    var forest: Forest
    
    public init(forest: Forest, cellSize: Int) {
        self.cellSize = cellSize
        self.forest = forest
        let size = forest.grid.size * cellSize
        let frame = CGRect(x: 0, y: 0, width: size, height: size)
        super.init(frame: frame)
        backgroundColor = UIColor.groundColor
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public override func draw(_ rect: CGRect) {
        let context = UIGraphicsGetCurrentContext()
        context?.saveGState()
        
        for y in 0..<forest.grid.size {
            for x in 0..<forest.grid.size {
                
                let coord = Coordinate(x: x, y: y)
                
                guard let drawableObject = forest.grid[coord] as? Drawable else {
                    continue
                }
                
                let x = coord.x * cellSize
                let y = coord.y * cellSize
                
                let origin = CGPoint(x: x, y: y)
//                let size = CGSize(width: cellSize, height: cellSize)
//                let smallRect = CGRect(origin: origin, size: size)
                
                let string = NSString(string: drawableObject.emoji)
                let font = UIFont.systemFont(ofSize: CGFloat(cellSize))
                string.draw(at: origin, withAttributes: [NSAttributedString.Key.font:font])
                
//                context?.setFillColor(drawableObject.color)
//                context?.fill(smallRect)
            }
        }
        
        context?.restoreGState()
    }
    
    public func autoRun() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            self.forest.update()
            self.setNeedsDisplay()
            self.autoRun()
        }
    }
    
}
