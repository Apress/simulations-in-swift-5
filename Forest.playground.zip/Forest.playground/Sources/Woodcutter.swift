import Foundation
import UIKit

public struct Woodcutter: Plottable, Moveable, Drawable {
    public var moveDistance = 3
    public var color = UIColor.woodcutterColor.cgColor
    public var emoji: String = "👨‍🚒"
}
