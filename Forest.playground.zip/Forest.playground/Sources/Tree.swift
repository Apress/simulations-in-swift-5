import Foundation
import UIKit

public struct Tree: Plottable, Drawable {
    
    public enum State {
        /// A tree just starting out.
        case seedling
        /// Fully grown. Can spawn seedlings.
        case mature
        /// Older tree. Seedling production increased.
        case elder
    }
    
    public var color: CGColor {
        switch state {
        case .seedling:
            return UIColor.seedlingColor.cgColor
        case .mature:
            return UIColor.matureTreeColor.cgColor
        case .elder:
            return UIColor.elderTreeColor.cgColor
        }
    }
    
    public var emoji: String {
        switch state {
        case .seedling:
            return "🌱"
        case .mature:
            return "🌲"
        case .elder:
            return "🌳"
        }
    }
    
    var seedlingSpawnChance: Float {
        switch state {
        case .seedling:
            return 0
        case .mature:
            return 0.1
        case .elder:
            return 0.2
        }
    }
    
    public var wood: Int {
        switch state {
        case .seedling:
            return 0
        case .mature:
            return 1
        case .elder:
            return 2
        }
    }
    
    public let state: State
    public let age: Int
    
    public init() {
        self.state = .mature
        self.age = 18
    }
    
    public init(state: State, age: Int) {
        self.state = state
        self.age = age
    }
    
    public var shouldSpawnSeedling: Bool {
        let randomSpawn = Float.random(in: 0..<1.0)
        if randomSpawn < seedlingSpawnChance {
            return true
        }
        return false
    }
    
}
