import UIKit
import PlaygroundSupport

let grid = Grid(size: 60)
let forest = Forest(grid: grid)
let view = ForestView(forest: forest, cellSize: 8)
view.autoRun()

PlaygroundPage.current.liveView = view
