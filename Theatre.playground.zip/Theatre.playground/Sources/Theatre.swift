import Foundation

public class Theatre {
    
    let capacity: Int
    public private(set) var seats = [Seat]()
    private var people = [Person]()
    
    public init(capacity: Int) {
        self.capacity = capacity
        
        for seatNumber in 0..<capacity {
            let seat = Seat(number: seatNumber, person: nil)
            seats.append(seat)
            let person = Person(assignedSeat: seatNumber)
            people.append(person)
        }
        
        let randomSeatNumber = Int.random(in: 0..<capacity)
        seats[randomSeatNumber].person = people.removeFirst()
    }
    
    func sit(person: Person, in seatNumber: Int) {
        if seats[seatNumber].person == nil {
            seats[seatNumber].person = person
        } else {
            let randomSeat = Int.random(in: 0..<seats.count)
            sit(person: person, in: randomSeat)
        }
    }
    
    public func sitPeople() {
        for person in people {
            sit(person: person, in: person.assignedSeat)
        }
    }
    
}
