import UIKit
import PlaygroundSupport

let height: Double = 0
let gravity: Double = -9.8
let deltaTime: Double = 0.05
let bounciness: Double = 0.9
let velocity: Double = 50
let angle: Double = 45 * (.pi / 180)

var verticalDisplacement: Double = height
var secondsElapsed: Double = 0
var horizontalVelocity = velocity * cos(angle)
var horizontalDisplacement: Double = 0
var verticalVelocity = velocity * sin(angle)

var maxHeight: Double = 0
var numberOfBounces = 0

while secondsElapsed <= 50 {
    
    if verticalDisplacement < 0 {
        verticalVelocity = -(verticalVelocity * bounciness)
    }
    
    secondsElapsed += deltaTime
    
    verticalDisplacement += verticalVelocity * deltaTime
    verticalVelocity += gravity * deltaTime
    horizontalDisplacement += horizontalVelocity * deltaTime
    
    if verticalDisplacement > maxHeight {
        maxHeight = verticalDisplacement
    }
}

print("Max Length:", horizontalDisplacement)
print("Max Height:", maxHeight)
print("Seconds Elapsed:", secondsElapsed)
