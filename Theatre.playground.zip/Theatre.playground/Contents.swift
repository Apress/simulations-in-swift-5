import Foundation

var lastPersonInAssignedSeat = 0
for _ in 0..<100 {
    let theatre = Theatre(capacity: 100)
    theatre.sitPeople()
    
    let lastSeat = theatre.seats.last
    
    if lastSeat?.person?.assignedSeat == lastSeat?.number {
        lastPersonInAssignedSeat += 1
    }
}

print(lastPersonInAssignedSeat)
