import Foundation
import UIKit

public protocol Plottable {}

public protocol Drawable {
    var color: CGColor { get }
    var emoji: String { get }
}

public protocol Moveable {
    var moveDistance: Int { get }
}


