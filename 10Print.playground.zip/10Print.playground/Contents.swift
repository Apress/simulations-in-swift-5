import UIKit
import PlaygroundSupport

let canvasSize = CGSize(width: 400, height: 400)
let tenPrint = TenPrint(gridSize: 20, canvasSize: canvasSize)

PlaygroundPage.current.liveView = tenPrint.view

let renderer = UIGraphicsImageRenderer(bounds: tenPrint.view.bounds)

let image = renderer.image { rendererContext in
    tenPrint.view.layer.render(in: rendererContext.cgContext)
}

let data = image.jpegData(compressionQuality: 1.0)

let rootUrl = playgroundSharedDataDirectory
let savePath = rootUrl.appendingPathComponent("10Print.jpg")

try? data?.write(to: savePath)
