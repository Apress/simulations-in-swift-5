import Foundation
import UIKit

extension UIColor {
    public static var seedlingColor: UIColor {
        return #colorLiteral(red: 0.45, green: 0.73, blue: 0.50, alpha: 1)
    }
    public static var matureTreeColor: UIColor {
        return #colorLiteral(red: 0.36, green: 0.60, blue: 0.21, alpha: 1)
    }
    public static var elderTreeColor: UIColor {
        return #colorLiteral(red: 0.24, green: 0.41, blue: 0.12, alpha: 1)
    }
    public static var bearColor: UIColor {
        return  #colorLiteral(red: 0.4, green:0.2, blue: 0.0, alpha: 1)
    }
    public static var woodcutterColor: UIColor {
        return  #colorLiteral(red: 0.8, green: 0, blue: 0, alpha: 1)
    }
    public static var groundColor: UIColor {
        return  #colorLiteral(red: 0.9, green:0.9, blue: 0.8, alpha: 1)
    }
}
