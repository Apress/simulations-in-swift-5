import Foundation

public struct Person {
    public let assignedSeat: Int
}

