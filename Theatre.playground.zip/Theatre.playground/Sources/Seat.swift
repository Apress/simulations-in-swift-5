import Foundation

public struct Seat {
    public let number: Int
    public var person: Person?
}
