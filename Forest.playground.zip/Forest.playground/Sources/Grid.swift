import Foundation
import UIKit

// MARK: - Grid
public typealias Coordinate = (x: Int, y: Int)

public struct Grid {
    
    public let size: Int
    var plottables: [Plottable]
    
    public init(size: Int) {
        self.size = size
        plottables = Array(repeating: Ground(), count: size * size)
    }
    
    public subscript(coordinate: Coordinate) -> Plottable? {
        get {
            if isInBounds(coordinate) {
                let index = coordinate.x * size + coordinate.y
                return plottables[index]
            }
            return nil
        }
        set {
            if isInBounds(coordinate) {
                let index = coordinate.x * size + coordinate.y
                plottables[index] = newValue ?? Ground()
            }
        }
    }
    
    func isInBounds(_ coordinate: Coordinate) -> Bool {
        let xBounds = coordinate.x >= 0 && coordinate.x < size
        let yBounds = coordinate.y >= 0 && coordinate.y < size
        return xBounds && yBounds
    }
    
    public func randomCoordinate() -> Coordinate {
        let randX = Int.random(in: 0..<size)
        let randY = Int.random(in: 0..<size)
        return Coordinate(x: randX, y: randY)
    }
    
    public func randCoordinate(near coord: Coordinate) -> Coordinate {
        let randDX = Int.random(in: -1..<2)
        let randDY = Int.random(in: -1..<2)
        
        let newX = coord.x + randDX
        let newY = coord.y + randDY
        let newCoord = Coordinate(x: newX, y: newY)
        
        guard newCoord != coord else {
            return randCoordinate(near: coord)
        }
        
        guard self[newCoord] != nil else {
            return randCoordinate(near: coord)
        }
        
        return newCoord
    }
    
    public func randGroundCoord(near coord: Coordinate) -> Coordinate? {
        var maxRetries = 3
        
        while maxRetries > 0 {
            let rand = randCoordinate(near: coord)
            
            if self[rand] is Ground {
                return rand
            }
            
            maxRetries -= 1
        }
        return nil
    }
    
}
