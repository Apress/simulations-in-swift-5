import Foundation
import UIKit
import PlaygroundSupport

public class TenPrint {
    
    public let view: UIView
    
    public init(gridSize: Int, canvasSize: CGSize) {
        let origin = CGPoint(x: 0, y: 0)
        let frame = CGRect(origin: origin, size: canvasSize)
        view = UIView(frame: frame)
        view.backgroundColor = #colorLiteral(red: 0, green: 0.2578732189, blue: 0.06886517286, alpha: 1)
        
        let path = UIBezierPath()
        for y in 0..<Int(canvasSize.height) where y % gridSize == 0 {
            for x in 0..<Int(canvasSize.width) where x % gridSize == 0 {
                if Int.random(in: 0..<2) == 0 {
                    path.move(to: CGPoint(x: x, y: y))
                    path.addLine(to: CGPoint(x: x + gridSize, y: y + gridSize))
                } else {
                    path.move(to: CGPoint(x: x, y: y + gridSize))
                    path.addLine(to: CGPoint(x: x + gridSize, y: y))
                }
            }
        }
        
        let layer = CAShapeLayer()
        layer.strokeColor = UIColor.green.cgColor
        layer.path = path.cgPath
        view.layer.addSublayer(layer)
    }
    
}
