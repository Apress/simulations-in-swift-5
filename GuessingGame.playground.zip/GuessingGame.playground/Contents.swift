import UIKit

let numberOfPuzzles = 1000
var numberOfCorrectGuesses = 0

var timesMyNumberIsLargest = 0
var timesMyNumberIsSmallest = 0
var timesMyNumberIsInBetween = 0

for _ in 0..<numberOfPuzzles {
    var win = false
    
    let firstNumber = Int.random(in: 0..<20)
    let secondNumber = Int.random(in: 999_980..<1_000_000)
    let myNumber = Int.random(in: 0..<1_000_000)
    
    if myNumber < firstNumber && firstNumber > secondNumber {
        win = true
        numberOfCorrectGuesses += 1
    } else if myNumber > firstNumber && firstNumber < secondNumber {
        win = true
        numberOfCorrectGuesses += 1
    }
    
    guard win == true else { continue }
    
    if myNumber >= max(firstNumber, secondNumber) {
        timesMyNumberIsLargest += 1
    } else if myNumber <= min(firstNumber, secondNumber) {
        timesMyNumberIsSmallest += 1
    } else {
        timesMyNumberIsInBetween += 1
    }
    
}

print("largest guess won \(timesMyNumberIsLargest) times.")
print("smallest and won \(timesMyNumberIsSmallest) times.")
print("inbetween and won \(timesMyNumberIsInBetween) times.")

print("correctly guessed \(numberOfCorrectGuesses) times out of \(numberOfPuzzles)")
