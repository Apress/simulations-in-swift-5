import Foundation
import UIKit

public struct Bear: Plottable, Moveable, Drawable {
    public var moveDistance = 6
    public var color = UIColor.bearColor.cgColor
    public var emoji: String = "🐻"
}
